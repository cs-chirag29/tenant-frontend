//package com.example.rentmate.test;
//
//import com.example.rentmate.model.Tenant;
//import com.example.rentmate.service.TenantService;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//@SpringBootTest
//public class TestTenantService {
//
//    @Autowired
//    private TenantService tenantService;
//
//    @Test
//    public void testGetAllTenants() {
//        List<Tenant> tenants = tenantService.getAllTenants();
//        assertNotNull(tenants); // Check that tenants is not null
//        System.out.println(tenants); // For debugging purposes
//    }
//}
