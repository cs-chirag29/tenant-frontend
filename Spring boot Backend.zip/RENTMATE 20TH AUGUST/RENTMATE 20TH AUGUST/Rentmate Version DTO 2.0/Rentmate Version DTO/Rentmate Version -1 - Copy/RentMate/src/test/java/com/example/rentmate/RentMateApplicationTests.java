package com.example.rentmate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
